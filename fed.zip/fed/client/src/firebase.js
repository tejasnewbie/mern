// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyBqD-mZt77w8CJ9HlSlQHWK87RvXFa3sjk",
  authDomain: "studentaboard-7d49b.firebaseapp.com",
  projectId: "studentaboard-7d49b",
  storageBucket: "studentaboard-7d49b.firebasestorage.app",
  messagingSenderId: "157954053728",
  appId: "1:157954053728:web:34187ed2b12bebcd34d505"
};

// Initialize Firebase
export const app = initializeApp(firebaseConfig);